#include "DoubleLinkedList.h"

#include <string>
#include <iostream>

// default constructor
DoubleLinkedList::DoubleLinkedList()
{
	// the double linked list is created with 0 nodes
	this->m_head = NULL;
	this->m_tail = NULL;
}

// methods
int DoubleLinkedList::findNode(std::string passenger)
{
	NodePlus* current = m_head;
	int position = 0;

	if (current == NULL)
	{
		return -1; // position variable will be set to the return value
	}

	// this while loop runs while a node's name isn't passenger and node's next isn't pointing to NULL
	while (current->m_name != passenger && current->m_next != NULL)
	{
		position++;
		current = current->m_next;
	}

	if (current->m_name != passenger)
	{
		return -1;
	}

	return position;
}

void DoubleLinkedList::addNodeAtHead(std::string passenger)
{
	// instantiating a new node
	NodePlus* node = new NodePlus(passenger);

	node->m_next = m_head;

	if (m_head != NULL)
	{
		m_head->m_prev = node;
	}
	else
	{
		// when there are no nodes in the list
		m_tail = node;
	}

	// sets head to the new node which takes care of all situations
	m_head = node;
}

void DoubleLinkedList::addNodeAtTail(std::string passenger)
{
	// handles the case of an empty list
	if (m_head == NULL)
	{
		// a node gets created and head and tail are set to that node
		addNodeAtHead(passenger);
		return;
	}

	NodePlus* current = m_head;

	// traverses through the double linked list
	// checks to see if passenger already exists
	while (current->m_next != NULL)
	{
		if (current->m_name == passenger)
		{
			std::cout << passenger << " is already on this flight.\n" << std::endl;
			return;
		}
		current = current->m_next;
	}
	if (current->m_name == passenger)
	{
		std::cout << passenger << " is already on this flight.\n" << std::endl;
		return;
	}
	NodePlus* node = new NodePlus(passenger);
	
	current->m_next = node;
	node->m_prev = current;
	m_tail = node; // the tail is updated
	std::cout << "\nThe passenger " << passenger << " was added to the flight." << std::endl;
}

void DoubleLinkedList::deleteNode(int position)
{
	// when the list is empty or the node isn't found
	if (m_head == NULL || position == -1)
	{
		std::cout << "Either the list is empty or the node does not exist." << std::endl;
		return;
	}

	NodePlus* current = m_head;
	// setting current to the node we want to delete
	for (int i = 0; i < position; i++)
	{
		current = current->m_next;
	}
	// if node to be deleted is the head node
	if (current == m_head)
	{
		// if there's only one node in the list
		if (m_head == m_tail)
		{
			m_tail = NULL;
		}
		m_head = current->m_next;
	}
	// change next if node to be deleted is not last node
	if (current->m_next != NULL)
	{
		current->m_next->m_prev = current->m_prev;
	}
	// change prev if node to be deleted is not first node
	if (current->m_prev != NULL)
	{
		current->m_prev->m_next = current->m_next;
	}
	// if node to be deleted is the tail node
	if (current == m_tail)
	{
		// the tail is set to the 2nd to last node so last node can be deleted
		m_tail = current->m_prev;
	}
	// delete the current node which is at the specified position
	delete current;
	return;
}

void DoubleLinkedList::sortList()
{

}

void DoubleLinkedList::printList()
{
	NodePlus* head = m_head;

	if (head == NULL)
	{
		std::cout << "There are currently no passengers on this flight.\n" << std::endl;
		return;
	}
	
	while (head->m_next != NULL)
	{
		std::cout << head->m_name << ", ";
		head = head->m_next;
	}
	// there is one more passenger to print out
	std::cout << head->m_name << "\n" << std::endl;

	return;
}

void DoubleLinkedList::printReverseList()
{
	NodePlus* tail = m_tail;

	if (tail == NULL)
	{
		std::cout << "There are currently no passengers on this flight.\n" << std::endl;
		return;
	}

	while (tail->m_prev != NULL)
	{
		std::cout << tail->m_name << ", ";
		tail = tail->m_prev;
	}
	// there is one more passenger to print out
	std::cout << tail->m_name << "\n" << std::endl;

	return;
}