#ifndef _DoubleLinkedList_H
#define _DoubleLinkedList_H

#include "Node.h"
#include "NodePlus.h"
#include <string>

class DoubleLinkedList
{
public:

	NodePlus* m_head;
	NodePlus* m_tail;

	// default constructor
	DoubleLinkedList();

	// methods
	int findNode(std::string passenger);
	void addNodeAtHead(std::string passenger);
	void addNodeAtTail(std::string passenger);
	void deleteNode(int position); // position is the position of the node in the linked list
	void sortList();
	void printList();
	void printReverseList();
};

#endif