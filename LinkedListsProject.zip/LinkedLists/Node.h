#ifndef _Node_H
#define _Node_H

#include "NodePlus.h"
#include <string>

class Node
{
public:

	int m_data;
	Node* m_next;
	NodePlus* m_dll; // pointer to a double linked list node

	// default constructor
	Node();

	// constructor with parameter
	Node(int data);
};

#endif