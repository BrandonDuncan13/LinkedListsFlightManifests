#include "NodePlus.h"

#include <string>

// default constructor
NodePlus::NodePlus()
{
	this->m_name = "";
	this->m_prev = NULL;
	this->m_next = NULL;
}

// constructor with parameter for name
NodePlus::NodePlus(std::string name)
{
	this->m_name = name;
	this->m_prev = NULL;
	this->m_next = NULL;
}