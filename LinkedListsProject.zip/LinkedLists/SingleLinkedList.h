#ifndef _SingleLinkedList_H
#define _SingleLinkedList_H

#include "DoubleLinkedList.h"

#include "Node.h"
#include "NodePlus.h"
#include <string>

class SingleLinkedList
{
public:

	Node* m_head;

	// default constructor
	SingleLinkedList();

	// methods
	int findNode(int flightNumber);
	DoubleLinkedList* addNode(int flightNumber);
	void deleteNode(int position); // position is the position of the node in the linked list
	void sortList();
};

#endif