#include "Node.h"
#include "NodePlus.h"
#include "SingleLinkedList.h"
#include "DoubleLinkedList.h"

#include <iostream>
#include <string.h>
#include <iomanip>

void driver();
int grabInput();
DoubleLinkedList* addFlight(SingleLinkedList flights, int position, int flightNumber);
int flightNum();
int passengerInput(int flight);
void displayMainMenu();
void displayPassMenu(int flight);

int main()
{
	int option = 0;
	int optionTwo = 0;

	// creating a single linked list of flights that has no nodes in it
	SingleLinkedList flights;

	do
	{
		option = grabInput();

		if (option == 1)
		{
			// run option 1 code
			int flightNumber = flightNum(); // for example 2430
			int position;

			// check to see if this flight is in the linked list, if not add it to the list
			position = flights.findNode(flightNumber); // searches linked list a node with entered flight number
			// allows us to edit nodes in list

			// passengers needs to be set to an empty DLL or an existing DLL
			DoubleLinkedList* passengers = addFlight(flights, position, flightNumber); // a flight is added if the flight wasn't found

			do
			{
				optionTwo = passengerInput(flightNumber);

				std::string passenger, first, last;

				if (optionTwo == 1)
				{
					// run optionTwo 1 code
					std::cout << "Enter the name of the passenger you want to add to flight " << flightNumber << "." << std::endl;
					std::cout << "The passenger's first name: " << std::endl;
					std::cin >> first;
					std::cout << "The passenger's last name: " << std::endl;
					std::cin >> last;
					passenger = first + " " + last;

					// add the passenger to the current flight
					passengers->addNodeAtTail(passenger);
				}
				else if (optionTwo == 2)
				{
					// run optionTwo 2 code
					std::cout << "Enter the name of the passenger you want to remove from flight " << flightNumber << "." << std::endl;
					std::cout << "The passenger's first name: " << std::endl;
					std::cin >> first;
					std::cout << "The passenger's last name: " << std::endl;
					std::cin >> last;
					passenger = first + " " + last;

					// find that passenger in the list for the flight and return -1 passenger doesn't exist
					int position = passengers->findNode(passenger);

					if (position == -1)
					{
						std::cout << "The passenger you entered was not found on this flight. Please try again!\n" << std::endl;
						// after this the user returns to the menu
					}
					else
					{
						// remove the passenger from the list or flight
						passengers->deleteNode(position);
						std::cout << "\nThe passenger " << passenger << " was deleted from the flight." << std::endl;
					}
				}
				else if (optionTwo == 3)
				{
					// run optionTwo 3 code
					passengers->printList();
				}
				else if (optionTwo == 4)
				{
					// run optionTwo 4 code
					passengers->printReverseList();
				}
				else
				{
					// run optionTwo 0 code
					std::cout << "Exiting flight " << flightNumber << ".\n" << std::endl;
				}
			}
			while (!(optionTwo == 0));
		}
		else if (option == 2)
		{
			// run option 2 code
			// could do a nested for loop to display passengers on each flight
			// will most likely use printList function and make a nice output format since it's used for both
		}
		else if (option == 3)
		{
			// run option 3 code
			driver();
		}
		else
		{
			// run option 0 code
			std::cout << "Exiting the program." << std::endl;
		}
	}
	while (!(option == 0));

	// waits for enter key press
	std::cin.get();
}

void displayMainMenu()
{
	std::cout << std::setw(12) << "=== MAIN MENU ===" << std::endl;
	std::cout << "1 - Press to make or change a reservation." << std::endl;
	std::cout << "2 - Press to Print all manifests." << std::endl;
	std::cout << "3 - For Driver." << std::endl;
	std::cout << "0 - Exit program\n" << std::endl;
}
void displayPassMenu(int flight)
{
	std::cout << std::setw(12) << "=== List of passengers ===" << std::endl;
	std::cout << "1 - Insert passenger onto flight " << flight << "." << std::endl;
	std::cout << "2 - Remove passenger from flight " << flight << "." << std::endl;
	std::cout << "3 - List passengers on flight " << flight << "." << std::endl;
	std::cout << "4 - List passengers by reverse order." << std::endl;
	std::cout << "0 - Exit flight " << flight << ".\n" << std::endl;
}

int grabInput()
{
	displayMainMenu();

	int userInput;
	std::cin >> userInput;

	while (!(userInput >= 0 && userInput <= 3))
	{
		std::cout << "Invalid option. Please make one of the following selections:\n" << std::endl;
		// display main menu
		displayMainMenu();

		std::cin >> userInput;
	}
	return userInput;
}

DoubleLinkedList* addFlight(SingleLinkedList flights, int position, int flightNumber)
{
	// if the flight number is not found
	if (position == -1)
	{
		// then the flight needs to be added to the list
		// a node for the flight is created and a DLL of passengers is created, and finally returned for use
		DoubleLinkedList* passengers = flights.addNode(flightNumber);

		return passengers;
	}
	// when the flight is found meaning it already exists
	else
	{
		//Node* selected;

		//for (int i = 0; i < )
		//{

		//}

		//DoubleLinkedList* passengers;
	}
}

int flightNum()
{
	std::cout << "Please Enter a Flight Number:" << std::endl;

	int userFlight;
	std::cin >> userFlight;

	while (!(userFlight >= 0 && userFlight <= 3000))
	{
		std::cout << "Invalid flight. Please enter a flight number between 0-3000:\n" << std::endl;
		std::cout << "Please Enter a Flight Number:" << std::endl;
		
		std::cin >> userFlight;
	}
	std::cout << "\n" << "Flight " << userFlight << " was selected." << std::endl;

	return userFlight;
}

int passengerInput(int flight)
{
	displayPassMenu(flight);

	int userInput;
	std::cin >> userInput;

	while (!(userInput >= 0 && userInput <= 4))
	{
		std::cout << "Invalid option. Please make one of the following selections:\n" << std::endl;
		// display the passenger menu
		displayPassMenu(flight);

		std::cin >> userInput;
	}
	return userInput;
}

void driver()
{
	// this is where the functionality will be written
}